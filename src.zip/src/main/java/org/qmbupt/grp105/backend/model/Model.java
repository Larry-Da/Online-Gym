package org.qmbupt.grp105.backend.model;

import com.alibaba.fastjson.JSONObject;

public interface Model {
    public JSONObject toJSON();
}
